1.  Extract file .zip
2.1 open home.html for user
2.2 open Admin_home.html for Admin

provide resolution for screen 1920 x 1080 pixels
**don't move any files out of folder**

